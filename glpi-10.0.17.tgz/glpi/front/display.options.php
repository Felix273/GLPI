<?php

/**
 * ---------------------------------------------------------------------
 *
 * GLPI - Gestionnaire Libre de Parc Informatique
 *
 * http://glpi-project.org
 *
 * @copyright 2015-2024 Teclib' and contributors.
 * @copyright 2003-2014 by the INDEPNET Development Team.
 * @licence   https://www.gnu.org/licenses/gpl-3.0.html
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

/**
 * @since 0.84
 */

if (!defined('GLPI_ROOT')) {
    include('../inc/includes.php');
}

Html::popHeader(__('Display options'), $_SERVER['PHP_SELF']);

if (!isset($_GET['itemtype'])) {
    Html::displayErrorAndDie("lost");
}
$itemtype = $_GET['itemtype'];
if (!isset($_GET["sub_itemtype"])) {
    $_GET["sub_itemtype"] = '';
}

if ($item = getItemForItemtype($itemtype)) {
    if (isset($_GET['update']) || isset($_GET['reset'])) {
        $sub_itemtype = $_GET["sub_itemtype"];
        if (!is_a($sub_itemtype, CommonDBTM::class, true)) {
            $sub_itemtype = '';
            unset($_GET['sub_itemtype']);
        }
        $item->updateDisplayOptions($_GET, $sub_itemtype);
    }
    $item->checkGlobal(READ);
    $item->showDislayOptions($_GET["sub_itemtype"]);
}

Html::popFooter();
